class DOMNodeCollection {
  constructor($el) {
    this.$el = $el;
    
  }
  empty() {
    for(let i = 0; i < this.$el.length; i++) {
      this.$el[i].innerHTML = "";
    }

    this.$el.forEach(function(ele) {
      ele.bind(this).innerHTML = "";
    });
  }

  remove() {

  }

  attr(att, val) {
    this.$el.forEach(el => {
      el[att] = val;
    });
  }


  addClass(className) {
    this.$el.forEach(el => {
      el.className = className;
    });
  }

  removeClass(className) {
    this.$el.forEach(el => {
      // debugger
      el.classList.remove(className);
    });
  }

  html(str) {
    if (typeof str === 'undefined') {
     const innerHtml =  this.$el[0].innerHTML;
     return innerHtml;
    } else {
      // console.log($el);
      for(let i = 0; i < this.$el.length; i++) {
        this.$el[i].innerHTML = str;
        
      }

      return this.$el;

      // console.log($el);
    }
  }

  find() {

  }

  children() {
    let arr = [];
    this.$el.forEach(el => {
      Array.from(el.children).forEach( child => {
        arr.push(child);
      });
    });
    return new DOMNodeCollection(arr);
  }

  parent() {
    let arr = [];
    this.$el.forEach(el => {
      Array.from(el.parent).forEach(parent => {
        arr.push(parent);
      });
    });
    return new DOMNodeCollection(arr);
  }
  append(element) {
    // if element is a string, then add to innerHTML
    // If HTML ele or jquery obj then use outerHTML
    
    this.$el.forEach(el => {
      if (typeof element === "string") {
        el.innerHTML += element;
      } else {
        el.innerHTML += element.outerHTML;
      }
    });
  }
}


module.exports = DOMNodeCollection;

