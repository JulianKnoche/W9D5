const DOMNodeCollection = require("./dom_node_collection.js");

window.$l = (arg) => {
  if (typeof arg === "string") {
    return getNodesFromDom(arg);
  } else if (arg instanceof HTMLElement) {
    const arr = Array.from(arg);
    return new DOMNodeCollection(arr);
  }


};

function getNodesFromDom(arg) {
  const nodeList = document.querySelectorAll(arg);
  const nodeArray = Array.from(nodeList);
  return new DOMNodeCollection(nodeArray);
}

// window.DOMNodeCollection = DOMNodeCollection;


// setInterval()